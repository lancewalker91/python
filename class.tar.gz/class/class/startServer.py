import subprocess
rc = subprocess.call(["python3 /data/majing/class/main.py"],shell=True)
#print("rc")
